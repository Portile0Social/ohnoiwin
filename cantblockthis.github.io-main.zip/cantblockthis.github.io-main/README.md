# unleashmysigmapowers.github.io:
  eaglercraft 1.8.8 u40 but with goguardian bypasses:
# Bypasses:
  - X-CACHE
  - Offline Support (for no-wifi bypass)
  - BeforeUnload Anti-Close
  - Self-Executer
# Coming soon?
  Custom website made for injections/embedding flash files, html files, and gba games?
